/**
 * Преведува грешки од Supabase во јасна порака што кажува што да се направи.
 * Најчеста причина за грешка при прво стартување е неизвршена шема.
 */
export function describeSupabaseError(error: { code?: string; message?: string } | null): string {
  if (!error) return "Непозната грешка при читање на податоците.";

  const message = error.message ?? "";
  const code = error.code ?? "";

  if (code === "PGRST205" || /could not find the table/i.test(message)) {
    const table = message.match(/'([^']+)'/)?.[1] ?? "бараната табела";
    return (
      `Табелата ${table} не постои во базата.\n\n` +
      "Изврши ја датотеката supabase/schema.sql во Supabase → SQL Editor за проектот " +
      "кон кој покажува NEXT_PUBLIC_SUPABASE_URL во .env.local. " +
      "Потоа рестартирај го серверот со npm run dev.\n\n" +
      `(детали: ${message})`
    );
  }

  if (/invalid api key|jwt/i.test(message)) {
    return (
      "Клучевите за базата не одговараат на адресата.\n\n" +
      "Провери дали NEXT_PUBLIC_SUPABASE_URL и NEXT_PUBLIC_SUPABASE_ANON_KEY се од истиот " +
      "Supabase проект (Project Settings → API).\n\n" +
      `(детали: ${message})`
    );
  }

  if (/permission denied/i.test(message)) {
    return (
      "Нема дозвола за читање од табелата.\n\n" +
      "Изврши ја датотеката supabase/schema.sql — таа ги поставува политиките за читање.\n\n" +
      `(детали: ${message})`
    );
  }

  return message || "Непозната грешка при читање на податоците.";
}

