-- AUTO WIND — шема на базата (Supabase / PostgreSQL)
--
-- Оваа датотека е безбедна за повеќекратно извршување (idempotent):
-- можеш да ја извршиш повеќе пати без грешки.
--
-- КАКО СЕ ИЗВРШУВА:
--   1. Отвори Supabase → твојот проект → SQL Editor
--   2. Копирај ја целата содржина на овој фајл и кликни Run
--   3. На крајот се извршува „notify pgrst, 'reload schema'“ — со тоа
--      апликацијата веднаш ги гледа новите табели
--
-- Ако апликацијата прикажува „Could not find the table 'public.vehicles'
-- in the schema cache“, тоа значи дека оваа шема не е извршена во проектот
-- кон кој покажува .env.local (NEXT_PUBLIC_SUPABASE_URL).

create extension if not exists pgcrypto;

-- ---------- возила ----------
create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,                      -- SEO адреса, на пр. bmw-320d-2019
  brand text not null,
  model text not null,
  version text,
  year integer not null,
  price_eur numeric,
  price_mkd numeric,
  mileage_km integer,
  fuel text,
  transmission text,
  engine text,
  power_kw integer,
  power_hp integer,
  drive text,
  color text,
  euro_standard text,
  registration text,
  description text,
  equipment text[] default '{}',
  status text not null default 'available',        -- available | reserved | sold
  featured boolean not null default false,          -- истакнато на почетна
  sort_order integer not null default 0,            -- редослед во понудата
  cover_url text,                                   -- главна фотографија
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- фотографии на возило ----------
create table if not exists public.vehicle_images (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  url text not null,
  storage_path text,                                -- патека во Storage (за бришење на фајлот)
  sort_order integer not null default 0,
  is_cover boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- контакт податоци на сајтот ----------
create table if not exists public.site_settings (
  id integer primary key,
  phone_display text,
  phone_e164 text,
  viber text,
  whatsapp text,
  email text,
  address text,
  hours text,
  updated_at timestamptz not null default now(),
  constraint site_settings_singleton check (id = 1)
);

create index if not exists vehicles_status_idx on public.vehicles (status);
create index if not exists vehicles_sort_idx on public.vehicles (sort_order, created_at desc);
create index if not exists vehicle_images_vehicle_idx on public.vehicle_images (vehicle_id, sort_order);

-- ---------- пристап ----------
-- Сајтот чита само преку јавниот (anon) клуч. Сите измени одат преку admin
-- панелот, кој го користи service_role клучот на серверот. Затоа овде има
-- само политики за читање — ништо не може да се менува од браузер.
alter table public.vehicles enable row level security;
alter table public.vehicle_images enable row level security;
alter table public.site_settings enable row level security;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='vehicles' and policyname='public read vehicles') then
    create policy "public read vehicles" on public.vehicles
      for select to anon, authenticated using (true);
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='vehicle_images' and policyname='public read vehicle images') then
    create policy "public read vehicle images" on public.vehicle_images
      for select to anon, authenticated using (true);
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='site_settings' and policyname='public read site settings') then
    create policy "public read site settings" on public.site_settings
      for select to anon, authenticated using (true);
  end if;
end $$;

-- ---------- автоматско ажурирање на updated_at ----------
create or replace function public.touch_updated_at() returns trigger as $$
begin new.updated_at = now(); return new; end; $$ language plpgsql;

do $$ begin
  if not exists (select 1 from pg_trigger where tgname = 'vehicles_touch') then
    create trigger vehicles_touch before update on public.vehicles
      for each row execute function public.touch_updated_at();
  end if;
end $$;

-- ---------- простор за фотографии ----------
insert into storage.buckets (id, name, public)
  values ('vehicle-photos', 'vehicle-photos', true)
  on conflict (id) do update set public = true;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='public read vehicle photos') then
    create policy "public read vehicle photos" on storage.objects
      for select to anon, authenticated using (bucket_id = 'vehicle-photos');
  end if;
end $$;

-- ---------- контакт податоци (почетна вредност, менуваш од admin панелот) ----------
insert into public.site_settings (id, phone_display, phone_e164, viber, whatsapp)
  values (1, '+389 78 262 045', '+38978262045', '+38978262045', '+38978262045')
  on conflict (id) do nothing;

-- ---------- освежување на кешот ----------
-- Без ова Supabase може да прикажува „Could not find the table ... in the schema cache“
-- додека не се освежи кешот на REST API-то.
notify pgrst, 'reload schema';

