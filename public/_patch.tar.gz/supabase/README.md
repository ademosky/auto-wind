# База на податоци — что очекува апликацијата

Сајтот користи **Supabase** за две работи:

1. **Postgres база** — за возилата, фотографиите и контакт податоците.
2. **Storage** — за самите фотографии.

---

## Што точно очекува апликацијата

Апликацијата ги користи овие табели. Ако некоја недостига, добиваш грешка од типот
`Could not find the table 'public.vehicles' in the schema cache`.

### Табела `public.vehicles`

| Колона | Тип | Забелешка |
|--------|-----|-----------|
| `id` | uuid | авто-генериран |
| `slug` | text | уникатен, SEO адреса (`bmw-320d-2019`) |
| `brand`, `model`, `version` | text | марка, модел, верзија |
| `year` | integer | година (задолжително) |
| `price_eur`, `price_mkd` | numeric | цена во евра и денари |
| `mileage_km` | integer | километри |
| `fuel`, `transmission`, `engine` | text | гориво, менувач, мотор |
| `power_kw`, `power_hp` | integer | моќност |
| `drive`, `color`, `euro_standard`, `registration` | text | погон, боја, Euro стандард, регистрација |
| `description` | text | детален опис |
| `equipment` | text[] | листа на опрема |
| `status` | text | `available` \| `reserved` \| `sold` |
| `featured` | boolean | истакнато на почетна |
| `sort_order` | integer | редослед во понудата |
| `cover_url` | text | главна фотографија |
| `created_at`, `updated_at` | timestamptz | авто |

### Табела `public.vehicle_images`

| Колона | Тип | Забелешка |
|--------|-----|-----------|
| `id` | uuid | авто |
| `vehicle_id` | uuid | врска кон `vehicles` — се брише со возилото |
| `url` | text | јавен линк до фотографијата |
| `storage_path` | text | патека во Storage (за бришење на фајлот) |
| `sort_order` | integer | редослед во галеријата |
| `is_cover` | boolean | дали е главна |
| `created_at` | timestamptz | авто |

### Табела `public.site_settings`

Еден единствен ред со `id = 1`: телефон, Viber, WhatsApp, е-пошта, адреса, работно време.

### Storage корпа

- Идентификатор: **`vehicle-photos`**
- Јавно читање (public), а качувањето оди преку admin панелот.

---

## Како се поставува базата

### Вариант А — нов Supabase проект

1. Отвори Supabase → **SQL Editor** → **New query**
2. Копирај ја целата содржина на `supabase/schema.sql`
3. Кликни **Run**

Фајлот е безбеден за повторно извршување и на крајот сам го освежува кешот на REST API-то.

### Вариант Б — поврзување на веќе поставена база

Само земај ги вредностите од Supabase → **Project Settings → API**:

```env
NEXT_PUBLIC_SUPABASE_URL=https://<проект>.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<anon public key>
SUPABASE_SERVICE_ROLE_KEY=<service_role secret key>
```

и стави ги во `.env.local`.

> `SUPABASE_SERVICE_ROLE_KEY` го заобиколува RLS — се користи само на серверот во admin панелот. Никогаш не го ставај во GitHub.

---

## Решавање на проблеми

| Порака | Причина | Решение |
|--------|---------|----------|
| `Could not find the table 'public.vehicles' in the schema cache` | Шемата не е извршена во проектот кон кој покажува `.env.local` | Изврши `supabase/schema.sql` во **тој** проект |
| Истата порака, но шемата е извршена | Застојан кеш на REST API-то | Во SQL Editor: `notify pgrst, 'reload schema';` |
| `Invalid API key` | Клучот е од друг проект | Провери дали URL и клучот се од **истиот** Supabase проект |
| `permission denied for table vehicles` | Недостасуваат политиките за читање | Изврши `supabase/schema.sql` |
| Сајтот е празен, без грешки | Нема внесени возила | Додај возило од `/admin` или внеси демо податоци |
| Фотографиите не се прикажуваат | Корпата `vehicle-photos` не е јавна | `supabase/schema.sql` ја прави јавна |

### Како да провериш кон кој проект си поврзан

```bash
grep NEXT_PUBLIC_SUPABASE_URL .env.local
```

Ако таа адреса не е проектот во кој ја изврши `schema.sql`, апликацијата нема да најде табели.

### Демо податоци

Шемата сама по себе не внесува возила. За да видиш како изгледа сајтот веднаш,
внеси неколку возила од `/admin`. Сите демо возила можеш да ги избришеш со едно кликнување
од листата во admin панелот.

